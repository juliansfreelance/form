var notext = false;

var nombretexto;
var editorial;
var neweditorial;
var edicion;

var recurso;
var newrecurso;

var datayear = [];

$(document).ready(function() {
    $('body').scrollTop(0);
    $('input:text[name="nombretexto"]').alphanum();
    $('input:text[name="edicion"]').numeric();

    $('input[type="checkbox"]').on('click', function(){
        notext = $("#notext").prop('checked');
        if (notext) { 
            $('.datatext, .otraeditorial, .otrorecurso').hide();
            $('.recurso').show();
        }
        else {
            $('.recurso, .otraeditorial, .otrorecurso').hide();
            $('.datatext').show();
        }
    });

    $('select[name="editorial"]').on('change', function() {
        editorial = $(this).val();
        
        if(editorial == 'otra') {
            $('.otraeditorial').show();
        }
        else if(editorial != 'otra') {
            $('.otraeditorial').hide();
        }
    });

    $('select[name="recurso"]').on('change', function() {
        $('.recurso_error').addClass('hidden');
        recurso = $(this).val();
        console.log(recurso);
        
        if(recurso == 'otra') {
            $('.otrorecurso').show();
        }
        else if(recurso != 'otra') {
            $('.otrorecurso').hide();
        }
    });

    $('.otraeditorial, .otrorecurso, .recurso').hide();

    $('.siguiente_btn').on('click', function() {
        $('.siguiente_btn').addClass('hidden');

        var pathname = window.location.pathname;
        pathname = pathname.split("/");
        var year = pathname[2];
        console.log(year);

        localStorage.removeItem('year 2018');
        localStorage.removeItem('Year_'+year);

        if (notext) { 
            recurso = $('select[name="recurso"]').val();
            if(recurso == 0) {
                $('.recurso_error').removeClass('hidden');
                $('.siguiente_btn').removeClass('hidden');
            }
            else if(recurso == 'otra') {
                newrecurso = $('input:text[name="newrecurso"]').val();
                if(newrecurso == '' || newrecurso == null) {
                    $('.newrecurso_error').html('*Por favor indique el recurso empleado.');
                    $('.newrecurso_error').removeClass('hidden');
                    $('.siguiente_btn').removeClass('hidden');
                }
                else if(newrecurso.length <= 5) {
                    $('.newrecurso_error').html('*Nombre del recurso demasiado corto.');
                    $('.newrecurso_error').removeClass('hidden');
                    $('.siguiente_btn').removeClass('hidden');
                }
                else {
                    datayear = ["newrecurso", newrecurso];
                    localStorage.setItem('Year_'+year, datayear);
                }
            }
            else {
                datayear = ["recurso", recurso];
                localStorage.setItem('Year_'+year, datayear);
            }
        }
        else {
            nombretexto = $('input:text[name="nombretexto"]').val();
            edicion = $('input:text[name="edicion"]').val();
            if(nombretexto == '' || nombretexto == null) {
                $('.nombretexto_error').html('*Por favor indique el nombre del texto.');
                $('.nombretexto_error').removeClass('hidden');
                $('.siguiente_btn').removeClass('hidden');
            }
            else if(nombretexto.length <= 8) {
                $('.nombretexto_error').html('*Nombre del texto demasiado corto.');
                $('.nombretexto_error').removeClass('hidden');
                $('.siguiente_btn').removeClass('hidden');
            }
            else if(editorial == 0) {
                $('.editorial_error').removeClass('hidden');
                $('.siguiente_btn').removeClass('hidden');
            }
            else if(editorial == 'otra') {
                neweditorial = $('input:text[name="neweditorial"]').val();
                if(neweditorial == '' || neweditorial == null) {
                    $('.neweditorial_error').html('*Por favor indique el nombre del la editorial del texto.');
                    $('.neweditorial_error').removeClass('hidden');
                    $('.siguiente_btn').removeClass('hidden');
                }
                else if(neweditorial.length <= 3) {
                    $('.neweditorial_error').html('*Nombre de la editorial demasiado corto.');
                    $('.neweditorial_error').removeClass('hidden');
                    $('.siguiente_btn').removeClass('hidden');
                }
                else if(edicion == '' || edicion == null) {
                    $('.edicion_error').removeClass('hidden');
                    $('.siguiente_btn').removeClass('hidden');
                }
                else if(edicion > 2021 || edicion < 1584 ) {
                    $('.edicion_error').removeClass('hidden');
                    $('.siguiente_btn').removeClass('hidden');
                }
                else {
                    datayear = ["texto", nombretexto, "new", newrecurso, edicion ];
                    localStorage.setItem('Year_'+year, datayear);
                }
            }
            else {
                datayear = ["texto", nombretexto, "old", editorial, edicion ];
                localStorage.setItem('Year_'+year, datayear);
            }
        }
    });
});