<a href="/">
    <img src="<?php echo e(asset('img/logo.svg')); ?>" alt="Inicio" class="w-1/2 m-auto">
</a><?php /**PATH C:\xampp\htdocs\form_ite\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>