<img src="<?php echo e(asset('img/logo.svg')); ?>" <?php echo e($attributes); ?>>

<?php /**PATH C:\xampp\htdocs\form_ite\resources\views/vendor/jetstream/components/application-logo.blade.php ENDPATH**/ ?>